/*
	Created by: James Abitria
	Class: CPT_S 121 Lab Section 7
	Assignment: Programming Assignment 6
	Date Created: 10-31-23
	
	Description: This program plays the game Battleship against the computer, where the game stats are logged into files, and the active
	board is posted each turn.
*/
#include "battleship.h"

int main() {
	// Randomizer for the random placement of ships.
	srand(time(NULL));
	// Variables needed for the game.
	FILE* gameStats = fopen("battleship.log", "w");
	Stats p1 = { 0, 0, 0, 0, False }, p2 = { 0, 0, 0, 0, False };
	Point p1Board[10][10], p2Board[10][10];
	Ship p1Ships[5], p2Ships[5];
	int turn = 0, selection = 0, row = 0, col = 0, shipHit = 0, segmentHit = 0;
	enum Boolean hit = False, sunk = False, playerWon = False;
	char hitSymbol = ' ';
	// Explains the rules of battleship, starts the shots boards, and selected the first player to make their turn.
	welcomeScreen();
	initializeGameBoard(p1Board);
	initializeGameBoard(p2Board);
	turn = selectFirstPlayer();
	// Player 1 ship placement mode. 
	printf("Player 1! Would you like to manually place your ships, or would you like the computer to place the ships?\n");
	printf("(0 is manual, 1 is automatic): ");
	scanf("%d", &selection);
	if (selection == 0) {
		manualPlaceShips(p1Ships);
	}
	else {
		randomPlaceShips(p1Ships);
	}
	displayShips(p1Ships);

	system("cls");
	// Player 2 ship placement mode.
	printf("Player 2! Would you like to manually place your ships, or would you like the computer to place the ships?\n");
	printf("(0 is manual, 1 is automatic): ");
	scanf("%d", &selection);
	if (selection == 0) {
		manualPlaceShips(p2Ships);
	}
	else {
		randomPlaceShips(p2Ships);
	}
	displayShips(p2Ships);
	
	// Game loops as long as no one has won.
	while (!playerWon) {
		// Player 1's turn.
		if (turn == 1) {
			system("cls");
			// Displays the current shots against the opponents and the state of their own ships.
			printf("Player 1!\nYour Shots:\n");
			displayBoard(p1Board);
			printf("\nYour Ships:\n");
			displayShips(p1Ships);
			// Prompts for a shot by row first, then by column.
			printf("Player 1! Please enter the coordinates for the location you'd like to shoot! (Enter two integers separated by space)\n");
			scanf("%d%d", &row, &col);
			// Checks for hit, sunk, and win conditions.
			hit = checkShot(row, col, p2Ships, &shipHit, &segmentHit);
			if (hit) {
				// Records the successful hit.
				p1.hits++;
				hitSymbol = p2Ships[shipHit].ship[segmentHit].symbol;
				p2Ships[shipHit].ship[segmentHit].symbol = 'X';
				printf("That's a hit!\n");
				sunk = checkSunk(p2Ships, shipHit);
				if (sunk) {
					// Prints a bonus message, and verifies if the game has ended.
					printf("That ship was sunk!!\n");
					playerWon = isWinner(p2Ships);
					p1.winner = playerWon;
				}
				system("pause");
			}
			// Miss condition and recording.
			else {
				p1.misses++;
				printf("Miss..\n");
				system("pause");
			}
			// Shot and move recorded, turn swapped.
			p1.shots++;
			updateBoard(p1Board, row, col, hit);
			outputMove(gameStats, turn, row, col, hit, sunk, hitSymbol);
			turn = 2;
		}
		// Player 2's turn. The commands are the exact same as Player 1's, so any comments made above apply in the same areas below.
		else {
			system("cls");
			printf("Player 2!\nYour Shots:\n");
			displayBoard(p2Board);
			printf("\nYour Ships:\n");
			displayShips(p2Ships);
			printf("Player 2! Please enter the coordinates for the location you'd like to shoot! (Enter two integers separated by space)\n");
			scanf("%d%d", &row, &col);
			hit = checkShot(row, col, p1Ships, &shipHit, &segmentHit);
			if (hit) {
				p2.hits++;
				hitSymbol = p1Ships[shipHit].ship[segmentHit].symbol;
				p1Ships[shipHit].ship[segmentHit].symbol = 'X';
				printf("That's a hit!\n");
				sunk = checkSunk(p1Ships, shipHit);
				if (sunk) {
					printf("That ship was sunk!!\n");
					playerWon = isWinner(p1Ships);
					p2.winner = playerWon;
				}
				system("pause");
			}
			else {
				p2.misses++;
				printf("Miss..\n");
				system("pause");
			}
			p2.shots++;
			updateBoard(p2Board, row, col, hit);
			outputMove(gameStats, turn, row, col, hit, sunk, hitSymbol);
			turn = 1;
		}
	}
	// Win message.
	if (p1.winner) {
		printf("PLAYER 1 WINS THE GAME\n");
	}
	else {
		printf("PLAYER 2 WINS THE GAME\n");
	}
	// End of game calculations: player hit-to-miss ratio, game is opened, and the game ends.
	p1.hitToMiss = (double)p1.hits / p1.shots;
	p2.hitToMiss = (double)p2.hits / p2.shots;
	outputStats(gameStats, p1, p2);
	fclose(gameStats);
	return 0;
}