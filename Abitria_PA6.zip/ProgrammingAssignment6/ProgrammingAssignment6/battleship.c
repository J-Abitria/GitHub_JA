/*
	Created by: James Abitria
	Class: CPT_S 121 Lab Section 7
	Assignment: Programming Assignment 6
	Date Created: 10-31-23

	Description: This program plays the game Battleship against the computer, where the game stats are logged into files, and the active
	board is posted each turn.
*/
#include "battleship.h"

/*
	Function: welcomeScreen
	Description: This function displays the rules of Battleship to the player.
	Precondition: main program was initialized and running
	Postcondition: The rules are printed to the screen, the program is paused successfully.
	
	Date Created: 10-31-23
	Last Update: 11-10-23
*/
void welcomeScreen() {
	printf("<<< Welcome to BattleShip! >>>\n");
	printf("\nThis version of batttleship is a 2 player game. BattleShip is played with 5 ");
	printf("different ships on an 10x10 board. The cruiser ship takes up 5 cells, the battleship takes up 4 cells, the submarine and ");
	printf("cruiser take up 3 cells, and the destroyer takes up 2 cells.\n\n");
	printf("You can choose to either manually place the ships on your board, or the computer can input them for you. On your turn, you ");
	printf("enter the coordinates of the point on the board you'd like to shoot at, row first (numbers on left), columns second (numbers on top). The shot can be a hit or miss. ");
	printf("If you hit all the cells where a ship is located, you sink the ship.");
	printf("The first person to sink all 5 of their opponent's ships, wins!\n");
	system("pause");
}

/*
	Function: initializeGameBoard
	Description: This function sets every point on the board to its designated position and sets their symbols to being blank.
	Precondition: Point board[10][10] is correctly initialized.
	Postcondition: Each point in the 2D array contains the corresponding row and column position, as well as a blank symbol -.
	
	Date Created: 11-1-23
*/
void initializeGameBoard(Point board[10][10]) {
	for (int row = 0; row < 10; row++) {
		for (int col = 0; col < 10; col++) {
			board[row][col].x = row;
			board[row][col].y = col;
			board[row][col].symbol = '-';
		}
	}
}

/*
	Function: selectFirstPlayer
	Description: This function prompts the user to enter the number of the player who will be going first, either 1 or 2.
	Precondition: main program is initialized and running
	Postcondition: The current integer value is returned.
	
	Date Created: 11-1-23
*/
int selectFirstPlayer() {
	system("cls");
	int selection = 0;
	printf("Which player is going first? Type 1 or 2: ");
	scanf("%d", &selection);
	if (selection > 1) {
		selection = 2;
	}
	else if (selection < 1) {
		selection = 1;
	}
	return selection;
}

/*
	Function: manualPlaceShips
	Description: This function prompts the user 5 times for the coordinate values of each of their ships. The user inputs the row
	and column respectively for the leftmost, or topmost position of the ship. The function will only continue if the entire ship
	fits within the bounds of the board, and is not overlapping at any point with any other ship. The board is shown each time with
	each ship being symbolized by different characters.
	Precondition: Ship* pShips is initialized correctly
	Postcondition: pShips has the correct values for each Point of the ship, as well as having the correct size ships shown.
	
	Date Created: 11-1-23
	Last Update: 11-10-23
*/
void manualPlaceShips(Ship* pShips) {
	int row = -1, col = -1, orientation = 0, size = 5, shipsMade = 0, count = 0;
	char type = ' ';
	while (shipsMade < 5) {
		switch (size) {
		case 5:
			type = 'C';
			break;
		case 4:
			type = 'b';
			break;
		case 3:
			type = 's';
			if (shipsMade == 3) {
				type = 'c';
			}
			break;
		case 2:
			type = 'd';
			break;
		}
		do {
			if (count > 0) {
				printf("Your ship does not fit in that area!\n");
				system("pause");
			}
			system("cls");
			if (shipsMade > 0) {
				displayShips(pShips);
			}
			printf("You will place your ships in descending order of size. The order is Carrier (5), Battleship (4), Submarine (3), Cruiser (3), and Destroyer (2).\n");
			printf("Ships are placed horizontally or vertically. The point you input is either the left side of the ship, or the top side of the ship.\n");
			printf("Enter the coordinates for where you want the ship to be placed!\n");
			printf("(Enter two integers separated by a space. Enter row first (numbers on left), then column (numbers on top): \n");
			printf("(Please enter a number between 0-9 to remain in the bounds of the board!)\n");
			scanf("%d%d", &row, &col);
			printf("Now, enter the orientation of the ship!\n");
			printf("(Enter 0 for horizontal, 1 for vertical.)\n");
			scanf("%d", &orientation);
			count++;
		} while (!isFree(pShips, row, col, orientation, size));
		if (orientation == 0) {
			for (int i = 0; i < size; i++) {
				pShips[shipsMade].ship[i].x = row;
				pShips[shipsMade].ship[i].y = col + i;
				pShips[shipsMade].ship[i].symbol = type;
			}
		}
		else {
			for (int i = 0; i < size; i++) {
				pShips[shipsMade].ship[i].x = row + i;
				pShips[shipsMade].ship[i].y = col;
				pShips[shipsMade].ship[i].symbol = type;
			}
		}
		shipsMade++;
		if (shipsMade != 3) {
			size--;
		}
		count = 0;
		displayShips(pShips);
		system("cls");
	}
}

/*
	Function: randomPlaceShips
	Description: This program automatically generates random position for each of the player's 5 ships. Using the same rules as 
	manualPlaceShips to place all ships on the board, with no overlap.
	Precondition: Ship* pShips is initialized correctly
	Postcondition: pShips has all the correct values for each Point and each Ship.
	
	Date Created: 11-3-23
	Last Update: 11-6-23
*/
void randomPlaceShips(Ship* pShips) {
	int row, col, orientation, size = 5, shipsMade = 0;
	char type = ' ';
	while (shipsMade < 5) {
		switch (size) {
		case 5:
			type = 'C';
			break;
		case 4:
			type = 'b';
			break;
		case 3:
			type = 's';
			if (shipsMade == 3) {
				type = 'c';
			}
			break;
		case 2:
			type = 'd';
			break;
		}
		orientation = rand() % 2;
		if (orientation == 0) {
			do {
				row = rand() % 10;
				col = rand() % (10 - size);
			} while (!isFree(pShips, row, col, orientation, size));
			for (int i = 0; i < size; i++) {
				pShips[shipsMade].ship[i].x = row;
				pShips[shipsMade].ship[i].y = col + i;
				pShips[shipsMade].ship[i].symbol = type;
			}
		}
		else {
			do {
				row = rand() % (10 - size);
				col = rand() % 10;
			} while (!isFree(pShips, row, col, orientation, size));
			for (int i = 0; i < size; i++) {
				pShips[shipsMade].ship[i].x = row + i;
				pShips[shipsMade].ship[i].y = col;
				pShips[shipsMade].ship[i].symbol = type;
			}
		}
		shipsMade++;
		if (shipsMade != 3) {
			size--;
		}
	}
}

/*
	Function: isFree
	Description: This function checks each ship that is currently stored in the pShips array, checking that every segment of the
	requested ship is not going to overlap any other ship, nor will it fall off of the board. It will check both the origin point
	and adjacent points for each ship before returning whether or not the space is available for the ship.
	Precondition: Ship* pShips, and ints row, col, orientation, and size are initialized correctly.
	Postcondition: A 1 is returned for the space being free for the given ship, and 0 if there is no space available.
	
	Date Created: 11-3-23
	Last Update: 11-8-23
*/
int isFree(Ship* pShips, int row, int col, int orientation, int size) {
	int tempRow = row, tempCol = col, space = 0, tempSize = 5;
	while (space < size) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < tempSize; j++) {
				if (pShips[i].ship[j].x == tempRow && pShips[i].ship[j].y == tempCol) {
					return 0;
				}
				if (tempRow >= 10 || tempCol >= 10) {
					return 0;
				}
			}
		}
		if (orientation == 0) {
			tempCol++;
		}
		else {
			tempRow++;
		}
		space++;
	}
	
	return 1;
}

/*
	Function: clearBoard
	Description: This function resets the board so that all spaces are set to a -
	Precondition: Point board[][10] is correctly initialized.
	Postcondition: Every symbol in board is set to a -.
	
	Date Created: 11-3-23
*/
void clearBoard(Point board[][10]) {
	for (int r = 0; r < 10; r++) {
		for (int c = 0; c < 10; c++) {
			board[r][c].symbol = '-';
		}
	}
}

/*
	Function: checkShot
	Description: This program checks if the targeted Point has a ship located there. If there is, the move is deemed a hit, if there is
	not, it is deemed a miss.
	Precondition: ints row and col, Ship* pShips, and int*'s shipHit and segmentHit are correctly initialized with appropriate values.
	Postcondition: True is returned if the given space is a hit, with the ship that was hit and the segment returned through pointers,
	and False is returned upon a miss.
	
	Date Created: 11-6-23
	Last Update: 11-8-23
*/
enum Boolean checkShot(int row, int col, Ship* pShips, int* shipHit, int* segmentHit) {
	int size = 5;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < size; j++) {
			if (pShips[i].ship[j].x == row && pShips[i].ship[j].y == col) {
				*shipHit = i;
				*segmentHit = j;
				return True;
			}
		}
		if (i != 2) {
			size--;
		}
	}
	return False;
}

/*
	Function: isWinner
	Description: This function determines if every ship on the player's board has been sunk. If it has, then the player who fired the
	sinking shot wins the game. If there is still a ship alive, then the game continues.
	Precondition: pShips has the correct values stored in its information
	Postcondition: True is returned if a player has successfully sunk all 5 ships, and False is returned if any ships survive.
	
	Date Created: 11-6-23
*/
enum Boolean isWinner(Ship* pShips) {
	int size = 5;
	enum Boolean won = True;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < size; j++) {
			if (pShips[i].ship[j].symbol != 'X') {
				won = False;
			}
		}
		if (i != 2) {
			size--;
		}
	}
	return won;
}

/*
	Function: updateBoard
	Description: This function sets the symbol of a given Point on the player's shots board to an X if the player hit a ship, and an
	O if the player misses.
	Precondition: Point pBoard[10][10], ints row and col, and enum Boolean hit are all correctly initialized with the proper values.
	Postcondition: The correct Point's symbol is successfully updated.
	
	Date Created: 11-6-23
*/
void updateBoard(Point pBoard[10][10], int row, int col, enum Boolean hit) {
	if (hit) {
		pBoard[row][col].symbol = 'X';
	}
	else {
		pBoard[row][col].symbol = 'O';
	}
}

/*
	Function: displayBoard
	Description: This function prints out the shots board for the given player. It prints an X for a hit segment of a ship, an O for
	a miss, and a - for an untargeted point.
	Precondition: Point board[10][10] is initialized with the correct current values.
	Postcondition: The player's shots board was correctly printed to the screen.
	
	Date Created: 11-1-23
*/
void displayBoard(Point board[10][10]) {
	printf("    0 || 1 || 2 || 3 || 4 || 5 || 6 || 7 || 8 || 9\n");
	for (int r = 0; r < 10; r++) {
		printf("%d ", r);
		for (int c = 0; c < 10; c++) {
			printf("| %c |", board[r][c].symbol);
		}
		printf("\n");
	}
}

/*
	Function: displayShips
	Description: This function prints the current ships board for the given player. It prints a - for a blank space, the corresponding
	symbol for a ship if it is present at that point, and an X for a hit ship.
	Precondition: pShips is initialized correctly with the appropriate values for the game state.
	Postcondition: The player's ships board is correctly displayed.
	
	Date Created: 11-6-23
	Last Update: 11-9-23
*/
void displayShips(Ship* pShips) {
	int ship = 0, segment = 0;
	printf("    0 || 1 || 2 || 3 || 4 || 5 || 6 || 7 || 8 || 9\n");
	for (int r = 0; r < 10; r++) {
		printf("%d ", r);
		for (int c = 0; c < 10; c++) {
			if (isShip(pShips, r, c, &ship, &segment)) {
				printf("| %c |", pShips[ship].ship[segment].symbol);
			}
			else {
				printf("| - |");
			}
		}
		printf("\n");
	}
	system("pause");
}

/*
	Function: isShip
	Description: This function determines if the given space is a ship, and what segment of the ship was found.
	Precondition: Ship* pShips, ints row and col, and int*'s ship and segment are properly initialized with correct values.
	Postcondition: True is returned if the given space is a ship, as well as the specific ship and segment from pointers, 
	and False is returned if the given space is not a ship.
	
	Date Created: 11-9-23
*/
enum Boolean isShip(Ship* pShips, int row, int col, int* ship, int* segment) {
	int size = 5;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < size; j++) {
			if (pShips[i].ship[j].x == row && pShips[i].ship[j].y == col) {
				*ship = i;
				*segment = j;
				return True;
			}
		}
		if (i != 2) {
			size--;
		}
	}
	return False;
}

/*
	Function: outputMove
	Description: This function prints each move by each player, the point targeted, if it was a hit or a miss, if it sunk a ship, 
	and which ship was sunk, into battleship.log
	Precondition: FILE* stats, ints turn, row, col, enum Booleans hit and sunk, and char hitSymbol are all correctly initialized with
	appropriate values.
	Postcondition: battleship.log contains information about the player's move.
	
	Date Created: 11-8-23
*/
void outputMove(FILE* stats, int turn, int row, int col, enum Boolean hit, enum Boolean sunk, char hitSymbol) {
	char* shipName = "";
	switch (hitSymbol) {
	case 'C':
		shipName = "carrier";
		break;
	case 'b':
		shipName = "battleship";
		break;
	case 's':
		shipName = "submarine";
		break;
	case 'c':
		shipName = "cruiser";
		break;
	case 'd':
		shipName = "destroyer";
		break;
	}
	fprintf(stats, "Player %d's Move:\n", turn);
	fprintf(stats, "Shot: (%d, %d)\n", row, col);
	fprintf(stats, "Result: ");
	if (hit) {
		fprintf(stats, "Hit\n");
		if (sunk) {
			fprintf(stats, "Ship %s was sunk.\n", shipName);
		}
	}
	else {
		fprintf(stats, "Miss\n");
	}
}

/*
	Function: checkSunk
	Description: This function checks if a hit ship has been successfully sunk.
	Precondition: Ship* pShips and int shipHit are storing the appropriate values.
	Postcondition: True is returned if every symbol of the ship is X, and returns false if there are unhit segments of the ship.
	
	Date Created: 11-6-23
*/
enum Boolean checkSunk(Ship* pShips, int shipHit) {
	int size, count = 0;
	enum Boolean isSunk = True;
	switch (shipHit) {
	case 0:
		size = 5;
		break;
	case 1:
		size = 4;
		break;
	case 2:
		size = 3;
		break;
	case 3:
		size = 3;
		break;
	case 4:
		size = 2;
		break;
	}
	while (count < size && isSunk) {
		if (pShips[shipHit].ship[count].symbol != 'X') {
			isSunk = False;
		}
		count++;
	}
	return isSunk;
}

/*
	Function: outputStats
	Description: This function prints the final stats for each player at the end of the game: hits, misses, hit-to-miss ratio, and the
	winning player. All this information is printed at the bottom of battleship.log.
	Precondition: FILE* stats, Stats* p1 and p2 are correctly initialized with the proper values.
	Postcondition: battleship.log contains the correct information about each player's game.
	
	Date Created: 11-8-23
	Last Update: 11-10-23
*/
void outputStats(FILE* stats, Stats p1, Stats p2) {
	fprintf(stats, "Player 1 Stats:\nHits: %d\nMisses: %d\nTotal Shots: %d\nHit-To-Miss Ratio: %.2lf\nWinner: ", p1.hits, p1.misses, p1.shots, p1.hitToMiss);
	if (p1.winner) {
		fprintf(stats, "Yes\n");
	}
	else {
		fprintf(stats, "No\n");
	}
	fprintf(stats, "Player 2 Stats:\nHits: %d\nMisses: %d\nTotal Shots: %d\nHIt-To-Miss Ratio: %.2lf\nWinner: ", p2.hits, p2.misses, p2.shots, p2.hitToMiss);
	if (p2.winner) {
		fprintf(stats, "Yes\n");
	}
	else {
		fprintf(stats, "No\n");
	}
}