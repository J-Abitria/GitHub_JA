/*
	Created by: James Abitria
	Class: CPT_S 121 Lab Section 7
	Assignment: Programming Assignment 6
	Date Created: 10-31-23

	Description: This program plays the game Battleship against the computer, where the game stats are logged into files, and the active
	board is posted each turn.
*/

#ifndef POINTERS_DEFINE_PARA_H
#define POINTERS_DEFINE_PARA_H
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

enum Boolean { True = 1, False = 0 };

typedef struct Point {
	int x;
	int y;
	char symbol;
} Point;

typedef struct Ship {
	Point ship[5];
} Ship;

typedef struct Stats {
	int hits;
	int misses;
	int shots;
	double hitToMiss;
	enum Boolean winner;
} Stats;

/*
	Function: welcomeScreen
	Description: This function displays the rules of Battleship to the player.
	Precondition: main program was initialized and running
	Postcondition: The rules are printed to the screen, the program is paused successfully.

	Date Created: 10-31-23
	Last Update: 11-1-23
*/
void welcomeScreen();

/*
	Function: initializeGameBoard
	Description: This function sets every point on the board to its designated position and sets their symbols to being blank.
	Precondition: Point board[10][10] is correctly initialized.
	Postcondition: Each point in the 2D array contains the corresponding row and column position, as well as a blank symbol -.

	Date Created: 11-1-23
*/
void initializeGameBoard(Point board[10][10]);

/*
	Function: selectFirstPlayer
	Description: This function prompts the user to enter the number of the player who will be going first, either 1 or 2.
	Precondition: main program is initialized and running
	Postcondition: The current integer value is returned.

	Date Created: 11-1-23
*/
int selectFirstPlayer();

/*
	Function: manualPlaceShips
	Description: This function prompts the user 5 times for the coordinate values of each of their ships. The user inputs the row
	and column respectively for the leftmost, or topmost position of the ship. The function will only continue if the entire ship
	fits within the bounds of the board, and is not overlapping at any point with any other ship. The board is shown each time with
	each ship being symbolized by different characters.
	Precondition: Ship* pShips is initialized correctly
	Postcondition: pShips has the correct values for each Point of the ship, as well as having the correct size ships shown.

	Date Created: 11-1-23
	Last Update: 11-10-23
*/
void manualPlaceShips(Ship* pShips);

/*
	Function: randomPlaceShips
	Description: This program automatically generates random position for each of the player's 5 ships. Using the same rules as
	manualPlaceShips to place all ships on the board, with no overlap.
	Precondition: Ship* pShips is initialized correctly
	Postcondition: pShips has all the correct values for each Point and each Ship.

	Date Created: 11-3-23
	Last Update: 11-6-23
*/
void randomPlaceShips(Ship* pShips);

/*
	Function: isFree
	Description: This function checks each ship that is currently stored in the pShips array, checking that every segment of the
	requested ship is not going to overlap any other ship, nor will it fall off of the board. It will check both the origin point
	and adjacent points for each ship before returning whether or not the space is available for the ship.
	Precondition: Ship* pShips, and ints row, col, orientation, and size are initialized correctly.
	Postcondition: A 1 is returned for the space being free for the given ship, and 0 if there is no space available.

	Date Created: 11-3-23
	Last Update: 11-8-23
*/
int isFree(Ship* pShips, int row, int col, int orientation, int size);

/*
	Function: clearBoard
	Description: This function resets the board so that all spaces are set to a -
	Precondition: Point board[][10] is correctly initialized.
	Postcondition: Every symbol in board is set to a -.

	Date Created: 11-3-23
*/
void clearBoard(Point board[10][10]);

/*
	Function: checkShot
	Description: This program checks if the targeted Point has a ship located there. If there is, the move is deemed a hit, if there is
	not, it is deemed a miss.
	Precondition: ints row and col, Ship* pShips, and int*'s shipHit and segmentHit are correctly initialized with appropriate values.
	Postcondition: True is returned if the given space is a hit, with the ship that was hit and the segment returned through pointers,
	and False is returned upon a miss.

	Date Created: 11-6-23
	Last Update: 11-8-23
*/
enum Boolean checkShot(int row, int col, Ship* pShips, int* shipHit, int* segmentHit);

/*
	Function: isWinner
	Description: This function determines if every ship on the player's board has been sunk. If it has, then the player who fired the
	sinking shot wins the game. If there is still a ship alive, then the game continues.
	Precondition: pShips has the correct values stored in its information
	Postcondition: True is returned if a player has successfully sunk all 5 ships, and False is returned if any ships survive.

	Date Created: 11-6-23
*/
int isWinner(Ship* pShips);

/*
	Function: updateBoard
	Description: This function sets the symbol of a given Point on the player's shots board to an X if the player hit a ship, and an
	O if the player misses.
	Precondition: Point pBoard[10][10], ints row and col, and enum Boolean hit are all correctly initialized with the proper values.
	Postcondition: The correct Point's symbol is successfully updated.

	Date Created: 11-6-23
*/
void updateBoard(Point board[10][10], int row, int col, enum Boolean hit);

/*
	Function: displayBoard
	Description: This function prints out the shots board for the given player. It prints an X for a hit segment of a ship, an O for
	a miss, and a - for an untargeted point.
	Precondition: Point board[10][10] is initialized with the correct current values.
	Postcondition: The player's shots board was correctly printed to the screen.

	Date Created: 11-1-23
*/
void displayBoard(Point board[10][10]);

/*
	Function: displayShips
	Description: This function prints the current ships board for the given player. It prints a - for a blank space, the corresponding
	symbol for a ship if it is present at that point, and an X for a hit ship.
	Precondition: pShips is initialized correctly with the appropriate values for the game state.
	Postcondition: The player's ships board is correctly displayed.

	Date Created: 11-6-23
	Last Update: 11-9-23
*/
void displayShips(Ship* pShips);

/*
	Function: outputMove
	Description: This function prints each move by each player, the point targeted, if it was a hit or a miss, if it sunk a ship,
	and which ship was sunk, into battleship.log
	Precondition: FILE* stats, ints turn, row, col, enum Booleans hit and sunk, and char hitSymbol are all correctly initialized with
	appropriate values.
	Postcondition: battleship.log contains information about the player's move.

	Date Created: 11-8-23
*/
void outputMove(FILE* stats, int turn, int row, int col, enum Boolean hit, enum Boolean sunk, char hitSymbol);

/*
	Function: checkSunk
	Description: This function checks if a hit ship has been successfully sunk.
	Precondition: Ship* pShips and int shipHit are storing the appropriate values.
	Postcondition: True is returned if every symbol of the ship is X, and returns false if there are unhit segments of the ship.

	Date Created: 11-6-23
*/
int checkSunk(Ship* pShips, int shipHit);

/*
	Function: outputStats
	Description: This function prints the final stats for each player at the end of the game: hits, misses, hit-to-miss ratio, and the
	winning player. All this information is printed at the bottom of battleship.log.
	Precondition: FILE* stats, Stats* p1 and p2 are correctly initialized with the proper values.
	Postcondition: battleship.log contains the correct information about each player's game.

	Date Created: 11-8-23
	Last Update: 11-10-23
*/
void outputStats(FILE* stats, Stats p1, Stats p2);
#endif